fav = [{'desc': 'so cute',
  'lists': ['ice-cream', 'beacon', 'vanilla'],
  'type': 'food'},
 {'desc': 'am scared', 'lists': ['dogs', 'not insect'], 'type': 'pet'}]
